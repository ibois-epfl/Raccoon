#pragma once

#include "compas.h"

inline void CGAL_Debug() {
	printf("\n");
}

inline void CGAL_Debug(size_t v) {
	printf("CPP size %zi\n", v);
}

inline void CGAL_Debug(bool v) {
	printf("CPP bool %i\n", v);
}

inline void CGAL_Debug(int v) {
	printf("CPP int %i\n", v);
}

inline void CGAL_Debug(double v) {
	printf("CPP double %f\n", v);
}

inline void CGAL_Debug(double x, double y, double z) {
	printf("CPP Vector %f %f %f \n", x, y, z);
}


inline void CGAL_Debug(CGAL_Vector v) {
	printf("CPP Vector %f %f %f \n", v.x(), v.y(), v.z());
}




inline void CGAL_Debug(CGAL_Point v) {
	printf("CPP Vector %f %f %f \n", v.x(), v.y(), v.z());
}
