#pragma once
#include "compas.h"

namespace CGAL_PlaneUtil {

   

    //inline void PlaneFromFourPoints(CGAL_Point& a, CGAL_Point& b, CGAL_Point& c, CGAL_Point& d, CGAL_Vector(&planeAxes)[4]) {
    //    // a----b
    //    // c----d
    //    MidVectorFromPoints(a, d, planeAxes[0]);

    //    planeAxes[1] = b - a;
    //    CGAL_VectorUtil::Unitize(planeAxes[1]);

    //    planeAxes[2] = a - c;
    //    CGAL_VectorUtil::Unitize(planeAxes[2]);

    //    planeAxes[3] = CGAL::cross_product(planeAxes[1], planeAxes[2]);
    //    CGAL_VectorUtil::Unitize(planeAxes[3]);

    //    planeAxes[2] = CGAL::cross_product(planeAxes[3], planeAxes[1]);
    //    CGAL_VectorUtil::Unitize(planeAxes[2]);
    //}


    inline CGAL_Vector PointAt2(CGAL_Vector(&input)[4], double s, double t)
    {
        return (input[0] + s * input[1] + t * input[2]);
    }

    inline CGAL_Vector PointAt(CGAL_Vector(&input)[4], double s, double t, double c)
    {
     
        return (input[0] + s * input[1] + t * input[2] + c * input[3]);
    }

    inline CGAL_Polyline PlaneToLine(CGAL_Point& point, CGAL_Plane& plane, double x = 1, double y = 1, double z = 1) {
 
        

        CGAL_Polyline axes(2);
        CGAL_Point center = point;
        CGAL_Vector n = plane.orthogonal_vector();
        CGAL_VectorUtil::Unitize(n);
        n *= 10;
        CGAL_Point normal = point + n;// +
        axes[0] = center;
        axes[1] = normal;

        //axes[0] = (CGAL_VectorUtil::ToPoint(input[0]));
        //axes[1] = (CGAL_VectorUtil::ToPoint(input[0]) + input[1] * x * 1.25);
        //axes[2] = (CGAL_VectorUtil::ToPoint(input[0]));
        //axes[3] = (CGAL_VectorUtil::ToPoint(input[0]) + input[2] * y);
        //axes[4] = (CGAL_VectorUtil::ToPoint(input[0]));
        //axes[5] = (CGAL_VectorUtil::ToPoint(input[0]) + input[3] * z);

        return axes;

    }

    inline CGAL_Polyline PlaneToPolyline(CGAL_Vector(&input)[4], double x = 1, double y = 1, double z = 1) {

        CGAL_Polyline axes(6);

        axes[0] = (CGAL_VectorUtil::ToPoint(input[0]));
        axes[1] = (CGAL_VectorUtil::ToPoint(input[0]) + input[1] * x * 1.25);
        axes[2] = (CGAL_VectorUtil::ToPoint(input[0]));
        axes[3] = (CGAL_VectorUtil::ToPoint(input[0]) + input[2] * y);
        axes[4] = (CGAL_VectorUtil::ToPoint(input[0]));
        axes[5] = (CGAL_VectorUtil::ToPoint(input[0]) + input[3] * z);

        return axes;

    }

    inline void Assign(CGAL_Vector(&source)[4], CGAL_Vector(&target)[4], int n) {
        for (int i = 0; i < n; i++)
            target[i] = source[i];
    }


    //inline ON_Plane PlaneFromLine(ON_Line& l, double t = 0) {
    //    ON_Plane pl(l.PointAt(t), l.Direction());
    //    return pl;
    //}

    //inline bool QuadFromLineAndTopBottomPlanes(ON_Plane& collisionFace, ON_Plane& pl0, ON_Plane& pl1, ON_Line& l, ON_Polyline& quad) {

    //    //Get two perpendicular planes of a line
    //    ON_Plane linePlane0 = PlaneFromLine(l, 0);
    //    ON_Plane linePlane1 = PlaneFromLine(l, 1);

    //    //Intersect 3 planes
    //    ON_3dPoint p0, p1, p2, p3;
    //    ON_Intersect(pl0, linePlane0, collisionFace, p0);
    //    ON_Intersect(linePlane0, pl1, collisionFace, p1);
    //    ON_Intersect(pl1, linePlane1, collisionFace, p2);
    //    ON_Intersect(linePlane1, pl0, collisionFace, p3);

    //    //Construction polyline
    //    ON_3dPoint points[5] = { p0,p1,p2,p3,p0 };
    //    //ON_Polyline quad;
    //    quad.Empty();
    //    quad.Append(5, points);

    //    return true;

    //}

    inline void AveragePlaneOrigin(CGAL_Vector(&pl0)[4], CGAL_Vector(&pl1)[4], CGAL_Vector(&result)[4]) {

        CGAL_Vector mid;
        CGAL_VectorUtil::MidVector(pl0[0], pl0[1], mid);

        result[0] = mid;
        result[1] = pl0[1];
        result[2] = pl0[2];
        result[3] = pl0[3];

    }




    inline bool IsSameDirection(CGAL_Plane pl0, CGAL_Plane pl1, bool canBeFlipped = true, double tolerance = 0.0001) {

        
        if (canBeFlipped) {
            return CGAL_VectorUtil::IsParallelTo(pl0.orthogonal_vector(), pl1.orthogonal_vector(),tolerance) != 0;
        }
        else {
            return CGAL_VectorUtil::IsParallelTo(pl0.orthogonal_vector(), pl1.orthogonal_vector(), tolerance) == 1;
        }

    }

    inline void ClosestPointTo( CGAL_Vector(&plane)[4], CGAL_Vector& p, CGAL_Vector& result )
    {
        const CGAL_Vector v (p.x() - plane[0].x(), p.y() - plane[0].y(), p.z() - plane[0].z());
        double s = v * plane[1];
        double t = v * plane[2];
        result = PointAt2(plane, s, t);
    }


    inline bool  IsSamePosition(CGAL_Plane pl0, CGAL_Plane pl1, double tolerance = 0.0001) {

        //CGAL_Debug(CGAL::squared_distance(pl0, pl1));
        //return CGAL::squared_distance(pl0, pl1) < tolerance;

       
       
        CGAL_Point p0 = pl0.point();
        CGAL_Point p1 = pl1.point();

        CGAL_Point cp0 = pl0.projection(p1);
        CGAL_Point cp1 = pl1.projection(p0);
  
      

       return CGAL_VectorUtil::DistanceSquare(cp0, p1) < tolerance && CGAL_VectorUtil::DistanceSquare(cp1,p0) < tolerance;
    }



    inline bool IsCoplanar(CGAL_Plane pl0, CGAL_Plane pl1, bool canBeFlipped = true, double tolerance = 0.01) {

       return IsSameDirection(pl0, pl1, canBeFlipped, tolerance) && IsSamePosition(pl0, pl1, tolerance);

    }


//    inline void AveragePlane(CGAL_Polyline& p, CGAL_Vector(&plane)[4] , bool alignToLongestEdge = false)
//    {
//        bool closed = CGAL_PolylineUtil::IsClosed(p) ;
//
//        if (alignToLongestEdge) {
//
//            int longestSegment = 0;
//            double len = 0;
//            for (int i = 0; i < p.size() - 1; i++) {
//                double d = CGAL_VectorUtil::DistanceSquare(p[i], p[i + 1]);
//                if (d < len) {
//                    len = d;
//                    longestSegment = i;
//                }
//            }
//            CGAL_Vector XAxis = p[longestSegment] - p[longestSegment + 1];
//            CGAL_Vector averageNormal;
//            CGAL_VectorUtil::AverageNormal(p, averageNormal, closed );
//            CGAL_Vector YAxis = CGAL::cross_product(plane[1], averageNormal);
//            return ON_Plane(p[0], XAxis, YAxis);
//        }
//
//        return ON_Plane(p[0], AverageNormal(p, closed));
//    }
//
//

}