#pragma once
#include "compas.h"
#include "CGAL_VectorUtil.h"
#include <math.h> 

namespace CGAL_XFormUtil {

    //https://stackoverflow.com/questions/23270292/a-point-cgal-transformation-between-two-coordinate-systems
    //https://github.com/mcneel/opennurbs/blob/7.x/opennurbs_xform.cpp Line1960
    inline CGAL_Transformation PlaneToPlane(
        CGAL_Vector O0, CGAL_Vector X0, CGAL_Vector Y0, CGAL_Vector Z0,
        CGAL_Vector O1, CGAL_Vector X1, CGAL_Vector Y1, CGAL_Vector Z1
    ) {

        // transformation maps P0 to P1, P0+X0 to P1+X1, ...

        //Move to origin -> T0 translates point P0 to (0,0,0)
        CGAL_Transformation T0(CGAL::TRANSLATION, CGAL_Vector(0 - O0.x(), 0 - O0.y(), 0 - O0.z()));


        //Rotate ->
        CGAL_Transformation F0(
            X0.x(), X0.y(), X0.z(),
            Y0.x(), Y0.y(), Y0.z(),
            Z0.x(), Z0.y(), Z0.z()
        );



        CGAL_Transformation F1(
            X1.x(), Y1.x(), Z1.x(),
            X1.y(), Y1.y(), Z1.y(),
            X1.z(), Y1.z(), Z1.z()
        );
        CGAL_Transformation  R = F1 * F0;


        //Move to 3d -> T1 translates (0,0,0) to point P1
        CGAL_Transformation T1(CGAL::TRANSLATION, CGAL_Vector(O1.x() - 0, O1.y() - 0, O1.z() - 0));

        return T1 * R * T0;
    }


    inline CGAL_Transformation PlaneToXY(
       CGAL_Point O0, CGAL_Plane plane
    ) {
        auto X0 = plane.base1();
        auto Y0 = plane.base2();
        auto Z0 = plane.orthogonal_vector();
        CGAL_VectorUtil::Unitize(X0);
        CGAL_VectorUtil::Unitize(Y0);
        CGAL_VectorUtil::Unitize(Z0);

        // transformation maps P0 to P1, P0+X0 to P1+X1, ...

        //Move to origin -> T0 translates point P0 to (0,0,0)
        CGAL_Transformation T0(CGAL::TRANSLATION, CGAL_Vector(0 - O0.x(), 0 - O0.y(), 0 - O0.z()));


        //Rotate ->
        CGAL_Transformation F0(
            X0.x(), X0.y(), X0.z(),
            Y0.x(), Y0.y(), Y0.z(),
            Z0.x(), Z0.y(), Z0.z()
        );


        return  F0 * T0;

    }

    inline CGAL_Transformation VectorsToXY(
        CGAL_Vector O0, CGAL_Vector X0, CGAL_Vector Y0, CGAL_Vector Z0
    ) {

        // transformation maps P0 to P1, P0+X0 to P1+X1, ...

        //Move to origin -> T0 translates point P0 to (0,0,0)
        CGAL_Transformation T0(CGAL::TRANSLATION, CGAL_Vector(0 - O0.x(), 0 - O0.y(), 0 - O0.z()));


        //Rotate ->
        CGAL_Transformation F0(
            X0.x(), X0.y(), X0.z(),
            Y0.x(), Y0.y(), Y0.z(),
            Z0.x(), Z0.y(), Z0.z()
        );


        return  F0 * T0;

    }

    inline CGAL_Transformation Scale(
        CGAL_Point O0, double s) {

        // transformation maps P0 to P1, P0+X0 to P1+X1, ...

        //Move to origin -> T0 translates point P0 to (0,0,0)
        CGAL_Transformation T0(CGAL::TRANSLATION, CGAL_Vector(0 - O0.x(), 0 - O0.y(), 0 - O0.z()));
        CGAL_Transformation T1(CGAL::SCALING, s);
        CGAL_Transformation T2(CGAL::TRANSLATION, CGAL_Vector(O0.x(), O0.y(), O0.z()));



        return  T2 * T1 * T0;

    }





    inline void RotationAroundAxis(
        double sin_angle,
        double cos_angle,
        CGAL_Vector axis,
        CGAL_Point center,
        CGAL_Transformation& xform
    )
    {
        xform = CGAL_Transformation(CGAL::Identity_transformation());

        // *this = ON_Xform::IdentityTransformation;

        for (;;)
        {
            // 29 June 2005 Dale Lear
            //     Kill noise in input
            if (fabs(sin_angle) >= 1.0 - ON_SQRT_EPSILON && fabs(cos_angle) <= ON_SQRT_EPSILON)
            {
                cos_angle = 0.0;
                sin_angle = (sin_angle < 0.0) ? -1.0 : 1.0;
                break;
            }

            if (fabs(cos_angle) >= 1.0 - ON_SQRT_EPSILON && fabs(sin_angle) <= ON_SQRT_EPSILON)
            {
                cos_angle = (cos_angle < 0.0) ? -1.0 : 1.0;
                sin_angle = 0.0;
                break;
            }

            if (fabs(cos_angle * cos_angle + sin_angle * sin_angle - 1.0) > ON_SQRT_EPSILON)
            {
                CGAL_Vector2 cs(cos_angle, sin_angle);
                if (CGAL_VectorUtil::Unitize2(cs))
                {
                    cos_angle = cs.x();
                    sin_angle = cs.y();
                    // no break here
                }
                else
                {
                    //ON_ERROR("sin_angle and cos_angle are both zero.");
                    cos_angle = 1.0;
                    sin_angle = 0.0;
                    break;
                }
            }

            if (fabs(cos_angle) > 1.0 - ON_EPSILON || fabs(sin_angle) < ON_EPSILON)
            {
                cos_angle = (cos_angle < 0.0) ? -1.0 : 1.0;
                sin_angle = 0.0;
                break;
            }

            if (fabs(sin_angle) > 1.0 - ON_EPSILON || fabs(cos_angle) < ON_EPSILON)
            {
                cos_angle = 0.0;
                sin_angle = (sin_angle < 0.0) ? -1.0 : 1.0;
                break;
            }

            break;
        }

        if (sin_angle != 0.0 || cos_angle != 1.0)
        {
            const double one_minus_cos_angle = 1.0 - cos_angle;
            CGAL_Vector a = axis;
            if (fabs(CGAL_VectorUtil::LengthSquared(a) - 1.0) > ON_EPSILON)
                CGAL_VectorUtil::Unitize(a);




            auto x00 = a.x() * a.x() * one_minus_cos_angle + cos_angle;
            auto x01 = a.x() * a.y() * one_minus_cos_angle - a.z() * sin_angle;
            auto x02 = a.x() * a.z() * one_minus_cos_angle + a.y() * sin_angle;

            auto x10 = a.y() * a.x() * one_minus_cos_angle + a.z() * sin_angle;
            auto x11 = a.y() * a.y() * one_minus_cos_angle + cos_angle;
            auto x12 = a.y() * a.z() * one_minus_cos_angle - a.x() * sin_angle;

            auto x20 = a.z() * a.x() * one_minus_cos_angle - a.y() * sin_angle;
            auto x21 = a.z() * a.y() * one_minus_cos_angle + a.x() * sin_angle;
            auto x22 = a.z() * a.z() * one_minus_cos_angle + cos_angle;

            auto x30 = 0.0;
            auto x31 = 0.0;
            auto x32 = 0.0;
            auto x33 = 1.0;


            if (center.x() != 0.0 || center.y() != 0.0 || center.z() != 0.0) {
                auto x03 = -((x00 - 1.0) * center.x() + x01 * center.y() + x02 * center.z());
                auto x13 = -(x10 * center.x() + (x11 - 1.0) * center.y() + x12 * center.z());
                auto x23 = -(x20 * center.x() + x21 * center.y() + (x22 - 1.0) * center.z());

                xform = CGAL_Transformation(
                    x00, x01, x02, x03,
                    x10, x11, x12, x13,
                    x20, x21, x22, x23
                    //x30, x31, x32, x33
                );

            }
            else {
                xform = CGAL_Transformation(
                    x00, x01, x02,
                    x10, x11, x12,
                    x20, x21, x22
                );

            }
        }


    }


    void AxisRotation(double angle, CGAL_Vector& axis, CGAL_Transformation& rot)
    {
        //create matrix of the rotation
        CGAL_Kernel::RT 
            c = cos(angle),   
            s = sin(angle),  
            ux(axis.x()), 
            uy(axis.y()), 
            uz(axis.z());

        CGAL_Kernel::RT matrix[12] =
        {
          ux * ux * (1 - c) + c, ux * uy * (1 - c) - uz * s, ux * uz * (1 - c) + uy * s, 0,
          ux * uy * (1 - c) + uz * s, uy * uy * (1 - c) + c, uy * uz * (1 - c) - ux * s, 0,
          ux * uz * (1 - c) - uy * s, uy * uz * (1 - c) + ux * s, uz * uz * (1 - c) + c, 0
        };

        rot = CGAL_Transformation(matrix[0], matrix[1], matrix[2],
            matrix[3], matrix[4], matrix[5],
            matrix[6], matrix[7], matrix[8],
            matrix[9], matrix[10], matrix[11]);
    }
}