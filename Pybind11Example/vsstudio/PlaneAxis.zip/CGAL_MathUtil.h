#pragma once
#include <math.h> 



namespace CGAL_MathUtil{


}
