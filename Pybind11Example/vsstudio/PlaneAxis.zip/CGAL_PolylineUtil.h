#pragma once
#include "compas.h"
#include "CGAL_VectorUtil.h"


namespace CGAL_PolylineUtil {



    inline bool IsClosed(CGAL_Polyline& input, double tolerance = 0.0001)
    {
        return CGAL_VectorUtil::DistanceSquare(input.front(), input.back())< tolerance;
       // CGAL_Point p0(0, 0, 0);
       // CGAL_Point p1(0, 0, 0);
       //double result =  CGAL_VectorUtil::DistanceSquare(p0, p1);
       // return result < tolerance;
    }


    inline CGAL_Point Center(CGAL_Polyline& input) {

        double x = 0, y = 0, z = 0;
        int n = input.size() - 1;

        for (int i = 0; i < n; i++) {
            x += input[i].x();
            y += input[i].y();
            z += input[i].z();
        }
        x /= n;
        y /= n;
        z /= n;

        CGAL_Point p(x, y, z);
        return  p;

    }

    inline CGAL_Vector CenterVec(CGAL_Polyline& input) {

        double x = 0, y = 0, z = 0;
        int n = input.size() - 1;

        for (int i = 0; i < n; i++) {
            x += input[i].x();
            y += input[i].y();
            z += input[i].z();
        }
        x /= n;
        y /= n;
        z /= n;

        CGAL_Vector p(x, y, z);
        return  p;

    }

    inline void Duplicate(CGAL_Polyline& input, CGAL_Polyline& output) {
       
        output.resize(input.size());
        for (int i = 0; i < input.size(); i++) {
            output[i] = CGAL_Point(input[i].x(), input[i].y(), input[i].z());
        }
      //  std::copy(input.begin(), input.end(), output.begin());
    }

    inline void Transform(CGAL_Polyline& input, CGAL_Transformation& transform) {

        for (auto it = input.begin(); it != input.end(); ++it) {
            *it = it->transform(transform);
            //printf("CPP Transformed Point %d %d %d \n", it->x(), it->y(), it->z());
        }

    }




    inline void AveragePlane(CGAL_Polyline& polyline, CGAL_Vector(&planeAxes)[4], bool closed = true) {

        //Origin
        planeAxes[0] = CenterVec(polyline);// CGAL_Vector(polyline[0].x(), polyline[0].y(), polyline[0].z());

        //XAxis
        planeAxes[1] = polyline[1] - polyline[0];
        CGAL_VectorUtil::Unitize(planeAxes[1]);

        //ZAxis
        CGAL_VectorUtil::AverageNormal(polyline, planeAxes[3], closed);

        //YAxis
        planeAxes[2] = CGAL::cross_product(planeAxes[3], planeAxes[1]);


        //printf("%f", planeAxes[1].squared_length());
        //printf("%f", planeAxes[2].squared_length());
        //printf("%f", planeAxes[3].squared_length());
        //printf("%f", CGAL::approximate_angle(planeAxes[1], planeAxes[2]));
        //printf("%f", CGAL::approximate_angle(planeAxes[1], planeAxes[3]));
        //printf("%f", CGAL::approximate_angle(planeAxes[2], planeAxes[3]));

        //GetOrthonormalVectors(planeAxes[3], planeAxes[1], planeAxes[2]);
    }

   

    inline bool PolylinePlane(CGAL_Polyline& polyline, CGAL_Plane& plane, CGAL_Polyline& alignmentPolyline, CGAL_Line& result) {

        return true;


        CGAL_Point pts[2];
        int count = 0;
        for (int i = 0; i < polyline.size()-1; i++) {

            CGAL_Line line(polyline[i], polyline[i + 1]);
            //CGAL_Plane plane (plane.origin, plane.zaxis);

            
            auto result = CGAL::intersection(line, plane);
  

            if (result) {
                //if (t > 1 || t < 0) continue;
                //pts[count] = line.PointAt(t);
                pts[count] = *boost::get<CGAL_Point>(&*result);
                count++;

                if (count == 2)
                    break;
            }

        }

        if (count == 2) {
            //double t0, t1;



            //alignmentPolyline.ClosestPointTo(pts[0], &t0);
            //alignmentPolyline.ClosestPointTo(pts[1], &t1);
            //result = (t0 > t1) ? CGAL_Line(pts[1], pts[0]) : CGAL_Line(pts[0], pts[1]);
            return true;
        }
        else {
            return false;
        }


    }



    //inline bool QuadFromLineAndTopBottomPlanes(ON_Plane& collisionFace, ON_Plane& pl0, ON_Plane& pl1, ON_Line& l, ON_Polyline& quad) {

    //    //Get two perpendicular planes of a line
    //    ON_Plane linePlane0 = PlaneFromLine(l, 0);
    //    ON_Plane linePlane1 = PlaneFromLine(l, 1);

    //    //Intersect 3 planes
    //    ON_3dPoint p0, p1, p2, p3;
    //    ON_Intersect(pl0, linePlane0, collisionFace, p0);
    //    ON_Intersect(linePlane0, pl1, collisionFace, p1);
    //    ON_Intersect(pl1, linePlane1, collisionFace, p2);
    //    ON_Intersect(linePlane1, pl0, collisionFace, p3);

    //    //Construction polyline
    //    ON_3dPoint points[5] = { p0,p1,p2,p3,p0 };
    //    //ON_Polyline quad;
    //    quad.Empty();
    //    quad.Append(5, points);

    //    return true;

    //}
   

}

//#endif


